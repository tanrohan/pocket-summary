import SwiftUI

@main
struct PocketNotesApp: App {
    var body: some Scene {
        WindowGroup {
            MeetingScreen()
                // New York, the system serif, is the one type family in the app.
                .fontDesign(.serif)
        }
    }
}
