import SwiftUI
import Foundation

enum Speaker: String {
    case maya, siobhan, tom, arjun

    var name: String { rawValue.capitalized }

    /// Each voice keeps one pastel wherever it appears.
    var tint: Color {
        switch self {
        case .maya: Palette.sky
        case .siobhan: Palette.sprout
        case .tom: Palette.iris
        case .arjun: Palette.rose
        }
    }
}

struct TranscriptLine: Identifiable {
    let id: Int
    let speaker: Speaker
    let time: String
    let text: String
    /// The phrase the summary is built from. Must be an exact substring of `text`.
    var highlight: String? = nil
}

struct Chapter: Identifiable {
    let id: String
    let title: String
    let lines: [TranscriptLine]
}

struct KeyPoint: Identifiable {
    let id: Int
    let title: String
    let text: String
    /// The transcript lines this point was drawn from, in the order they were said.
    let sourceLines: [Int]
}

struct ActionItem: Identifiable {
    let id: Int
    let owner: Speaker
    let task: String
    /// Empty when the conversation did not specify a deadline.
    let due: String
}

struct MeetingSummary {
    let headline: String
    /// The few words in the headline that matter most. Must be a substring of it.
    let headlineMark: String
    let overview: String
    let keyPoints: [KeyPoint]
    let actions: [ActionItem]

    var stepCount: Int { 1 + keyPoints.count + actions.count }
}

struct Meeting {
    let title: String
    let date: String
    let duration: String
    let durationSeconds: Double
    let participants: [Speaker]
    /// The full transcript, grouped by topic.
    let chapters: [Chapter]
    /// The moments shown while the recording is being transcribed.
    let moments: [TranscriptLine]
    let summary: MeetingSummary
    /// Who was speaking through the recording: where each line starts, as a
    /// fraction of its length, and who said it.
    let voiceStarts: [Double]
    /// Every line in order, matching `voiceStarts`.
    let allLines: [TranscriptLine]
    let voiceSpeakers: [Speaker]
    /// Where the highlighted moments fall, as fractions of the recording.
    let markFractions: [Double]

    init(
        title: String, date: String, duration: String, durationSeconds: Double,
        participants: [Speaker], chapters: [Chapter], momentIDs: [Int], summary: MeetingSummary
    ) {
        self.title = title
        self.date = date
        self.duration = duration
        self.durationSeconds = max(durationSeconds, 1)
        self.participants = participants
        self.chapters = chapters
        let lines = chapters.flatMap(\.lines)
        self.moments = momentIDs.compactMap { id in lines.first { $0.id == id } }
        self.summary = summary

        let length = max(durationSeconds, 1)
        self.voiceStarts = lines.map { Meeting.seconds($0.time) / length }
        self.voiceSpeakers = lines.map(\.speaker)
        self.allLines = lines
        self.markFractions = lines.filter { $0.highlight != nil }.map { Meeting.seconds($0.time) / length }
    }

    /// Turns "23:07" into seconds from the start of the recording.
    private static func seconds(_ time: String) -> Double {
        let parts = time.split(separator: ":").compactMap { Double($0) }
        return parts.count == 2 ? parts[0] * 60 + parts[1] : 0
    }

    var highlightedLineIDs: Set<Int> {
        Set(chapters.flatMap(\.lines).filter { $0.highlight != nil }.map(\.id))
    }

    /// The line being spoken at a point in the recording (0 to 1).
    func line(at fraction: Double) -> TranscriptLine? {
        guard !allLines.isEmpty else { return nil }
        var index = 0
        while index + 1 < voiceStarts.count, voiceStarts[index + 1] <= fraction {
            index += 1
        }
        return allLines[index]
    }

    func line(_ id: Int) -> TranscriptLine? {
        for chapter in chapters {
            if let line = chapter.lines.first(where: { $0.id == id }) {
                return line
            }
        }
        return nil
    }

    func fraction(for lineID: Int) -> Double? {
        guard let index = allLines.firstIndex(where: { $0.id == lineID }) else { return nil }
        return voiceStarts[index]
    }

    func timestamp(at fraction: Double) -> String {
        let seconds = Int((min(max(fraction, 0), 1) * durationSeconds).rounded())
        return String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}

extension Meeting {
    /// The Atlas launch review from the original recording kit. The transcript is
    /// the real one; the summary is rewritten to reflect where the meeting ended.
    static let atlasLaunchReview = Meeting(
        title: "Atlas launch review",
        date: "Thursday, October 8 at 4:00 PM",
        duration: "28 min",
        durationSeconds: 1686,
        participants: [.maya, .siobhan, .tom, .arjun],
        chapters: atlasChapters,
        momentIDs: [20, 59, 94, 250, 254, 256, 274, 280],
        summary: MeetingSummary(
            headline: "Launch moves to November 10.",
            headlineMark: "November 10",
            overview: "Two extra weeks allow the team to fix sharing permissions and complete the security retest.",
            keyPoints: [
                KeyPoint(
                    id: 1,
                    title: "The release plan",
                    text: "Code freeze moves to November 3. The initial rollout stays at 10%.",
                    sourceLines: [280, 287, 288]),
                KeyPoint(
                    id: 2,
                    title: "Engineering",
                    text: "Three launch blockers remain. The offline sync fix is in review.",
                    sourceLines: [20, 23]),
                KeyPoint(
                    id: 3,
                    title: "Design",
                    text: "Dark mode follows launch. Onboarding is down from seven steps to four.",
                    sourceLines: [64, 94]),
            ],
            actions: [
                ActionItem(id: 1, owner: .maya, task: "Tell Rachel the new launch date", due: ""),
                ActionItem(id: 2, owner: .siobhan, task: "Send Maya the pen test summary", due: "Tonight"),
                ActionItem(id: 3, owner: .tom, task: "Update the launch plan", due: ""),
            ]
        )
    )
}
