import SwiftUI
import Observation

/// Simulates upload, transcription, and summary generation locally, with no
/// backend. The views only read this state; the timeline lives here.
@Observable
@MainActor
final class MeetingProcessor {
    enum Phase: Int, Comparable {
        case uploading, transcribing, distilling, summarizing, ready

        static func < (lhs: Phase, rhs: Phase) -> Bool {
            lhs.rawValue < rhs.rawValue
        }
    }

    let meeting: Meeting

    private(set) var phase: Phase = .uploading
    private(set) var uploadProgress = 0.0
    /// How many transcript moments have arrived so far.
    private(set) var visibleLines = 0
    /// Lines whose key phrase has been marked.
    private(set) var highlighted: Set<Int> = []
    /// How much of the summary is written: the overview, then each key point,
    /// then each next step. See `MeetingSummary.stepCount`.
    private(set) var summaryStep = 0

    @ObservationIgnored private var run: Task<Void, Never>?
    @ObservationIgnored private var reduceMotion = false

    init(meeting: Meeting) {
        self.meeting = meeting
    }

    var transcriptionProgress: Double {
        Double(visibleLines) / Double(max(meeting.moments.count, 1))
    }

    /// Plays the whole experience from the top.
    func start(reduceMotion: Bool = false) {
        stop()
        self.reduceMotion = reduceMotion
        phase = .uploading
        uploadProgress = 0
        visibleLines = 0
        highlighted = []
        summaryStep = 0
        run = Task { [weak self] in
            await self?.play()
        }
    }

    /// Stops the timeline, leaving whatever is on screen in place.
    func stop() {
        run?.cancel()
        run = nil
    }

    /// Jumps straight to the finished summary.
    func finish() {
        stop()
        update {
            uploadProgress = 1
            visibleLines = meeting.moments.count
            highlighted = meeting.highlightedLineIDs
            summaryStep = meeting.summary.stepCount
            phase = .ready
        }
    }

    func setReduceMotion(_ enabled: Bool) {
        reduceMotion = enabled
    }

    private func update(_ changes: () -> Void) {
        withAnimation(reduceMotion ? nil : .smooth(duration: 0.65), changes)
    }

    private func wait(_ seconds: Double) async throws {
        try await Task.sleep(for: .seconds(seconds))
    }

    private func play() async {
        do {
            // Upload
            try await wait(0.8)
            for progress in [0.12, 0.33, 0.56, 0.82, 1.0] {
                update { uploadProgress = progress }
                try await wait(0.6)
            }
            try await wait(0.2)

            // Transcribe: each line arrives, then its key phrase is marked.
            update { phase = .transcribing }
            try await wait(0.5)
            for line in meeting.moments {
                update { visibleLines += 1 }
                try await wait(0.7)
                if line.highlight != nil {
                    update { _ = highlighted.insert(line.id) }
                }
                // Longer passages stay a little longer before the next arrives.
                let words = line.text.split(separator: " ").count
                try await wait(0.9 + min(1.5, Double(words) * 0.04))
            }

            // Distil: the transcript falls away until only the marked phrases
            // are left. The view choreographs this; the timeline just waits.
            try await wait(0.4)
            update { phase = .distilling }
            try await wait(3.5)

            // Insert the destination headline in the same transaction that
            // removes the quote, so its highlighted date can travel intact.
            withAnimation(reduceMotion ? nil : .smooth(duration: 1.0)) {
                phase = .summarizing
                summaryStep = 1
            }
            try await wait(3.5)
            let keyPointsEnd = 1 + meeting.summary.keyPoints.count
            if meeting.summary.stepCount >= 2 {
                for step in 2...meeting.summary.stepCount {
                    update { summaryStep = step }
                    try await wait(step <= keyPointsEnd ? 2.0 : 1.0)
                }
            }
            try await wait(0.5)

            update {
                highlighted = meeting.highlightedLineIDs
                phase = .ready
            }
        } catch {
            // Cancelled by a replay or a skip.
        }
    }
}
