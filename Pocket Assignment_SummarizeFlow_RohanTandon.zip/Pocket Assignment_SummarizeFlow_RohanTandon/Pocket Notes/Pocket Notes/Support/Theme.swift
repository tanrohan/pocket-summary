import SwiftUI

/// Paper for reading, one green for progress, yellow for what was said, and
/// one pastel per person. Every color has a day and a night value, defined in
/// the asset catalog.
enum Palette {
    static let paper = Color("Paper")
    /// Audio that has not been processed yet.
    static let mist = Color("Mist")
    /// Hairlines between items and sections.
    static let rule = Color("Rule")

    /// The warm gray that tints the top section of the page.
    static let wash = Color("Wash")

    static let ink = Color("Ink")
    static let inkSoft = Color("InkSoft")
    static let sage = Color("Sage")

    /// The one green: progress, the selected tab, completed checks.
    static let leaf = Color("Leaf")
    /// Text set on top of the green.
    static let onLeaf = Color("OnLeaf")

    static let sun = Color("Sun")
    /// The highlighter stroke behind a quoted phrase.
    static let marker = Color("Marker")

    static let sky = Color("Sky")
    static let sprout = Color("Sprout")
    static let iris = Color("Iris")
    static let rose = Color("Rose")
    /// Initials on a pastel badge stay dark in both appearances.
    static let badgeInk = Color(red: 0.09, green: 0.10, blue: 0.08).opacity(0.8)
}

/// One family, with semantic styles that scale with Dynamic Type.
enum TypeScale {
    /// The meeting title: the largest text on the page.
    static let title = Font.system(.largeTitle, weight: .semibold)
    /// The summary's one-line takeaway.
    static let headline = Font.system(.title2, weight: .semibold)
    /// A clear landmark between topics in the long transcript.
    static let chapter = Font.system(.title, weight: .semibold)
    static let section = Font.system(.headline, weight: .semibold)
    static let label = Font.system(.subheadline, weight: .semibold)
    static let lead = Font.system(.title3)
    static let body = Font.system(.body)
    static let transcript = Font.system(.body)
    static let subhead = Font.system(.subheadline)
    static let meta = Font.system(.footnote)
}

/// Content fades in, sharpens, and settles upward into place.
struct SettleModifier: ViewModifier {
    let amount: Double
    func body(content: Content) -> some View {
        content.opacity(1 - amount).blur(radius: amount * 2).offset(y: amount * 7)
    }
}

extension AnyTransition {
    static func settle(reduceMotion: Bool) -> AnyTransition {
        reduceMotion ? .opacity : .modifier(
            active: SettleModifier(amount: 1), identity: SettleModifier(amount: 0)
        )
    }
}

/// A press dims and slightly shrinks the label, with no added chrome.
struct QuietButtonStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.65 : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.97 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: configuration.isPressed)
    }
}

/// A hairline that separates one item or section from the next.
struct Hairline: View {
    var body: some View {
        Rectangle()
            .fill(Palette.rule)
            .frame(height: 1)
            .accessibilityHidden(true)
    }
}

/// Quiet, noninteractive context kept beside the text it belongs to.
struct MetadataChip: View {
    let text: String

    var body: some View {
        Text(text)
            .font(TypeScale.meta.weight(.medium))
            .foregroundStyle(Palette.inkSoft)
            .fixedSize()
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(Palette.ink.opacity(0.06), in: Capsule())
    }
}

/// Paper, with a warm-gray wash over the top section only: strongest at the
/// top of the screen and fading to nothing by `bottom`, the lower edge of the
/// recording ribbon. It is positioned in screen coordinates, so the page, the
/// top bar, and the ribbon all paint one continuous gradient.
struct TopWash: View {
    /// Where the top section ends, measured from the top of the screen.
    let bottom: CGFloat

    var body: some View {
        GeometryReader { geometry in
            Palette.paper
            LinearGradient(
                colors: [Palette.wash, Palette.wash.opacity(0.3), Palette.wash.opacity(0)],
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(height: max(bottom, 0))
            .offset(y: -geometry.frame(in: .global).minY)
        }
        .clipped()
        .accessibilityHidden(true)
    }
}
