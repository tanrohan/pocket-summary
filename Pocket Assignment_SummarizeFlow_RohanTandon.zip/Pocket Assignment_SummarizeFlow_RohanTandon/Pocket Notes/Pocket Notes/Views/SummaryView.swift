import SwiftUI

/// Everything between "recording ended" and "ready to read", in one column:
/// the recording uploads, the conversation builds, its key phrases are
/// distilled, and the summary is written from them.
struct SummaryView: View {
    let processor: MeetingProcessor
    @Binding var completed: Set<Int>
    /// Links each key point to the sheet that opens from it.
    let sources: Namespace.ID
    /// Shows the moments in the conversation a key point came from.
    let onSource: (KeyPoint) -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Namespace private var takeaway
    @State private var headlineHasLanded = false

    private var meeting: Meeting { processor.meeting }
    private var summary: MeetingSummary { meeting.summary }
    private var phase: MeetingProcessor.Phase { processor.phase }
    private var step: Int { processor.summaryStep }
    private var isWriting: Bool { phase == .summarizing }
    private var actionsStart: Int { 2 + summary.keyPoints.count }
    private var settle: AnyTransition { .settle(reduceMotion: reduceMotion) }
    private var allDone: Bool { completed.count == summary.actions.count }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if phase == .uploading {
                uploadNote
                    .transition(settle)
            } else if phase == .transcribing || phase == .distilling {
                LiveTranscript(
                    lines: Array(meeting.moments.prefix(processor.visibleLines)),
                    highlighted: processor.highlighted,
                    isDistilling: phase == .distilling,
                    headlineMark: summary.headlineMark,
                    takeaway: takeaway
                )
                // The shared date must stay opaque while its surrounding
                // transcript is replaced by the headline.
                .transition(.identity)
            } else {
                written
                    .transition(.identity)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .task(id: phase) {
            if phase == .summarizing {
                if !reduceMotion {
                    do { try await Task.sleep(for: .seconds(0.85)) }
                    catch { return }
                }
                guard !Task.isCancelled else { return }
                withAnimation(reduceMotion ? nil : .easeOut(duration: 0.3)) {
                    headlineHasLanded = true
                }
            } else {
                headlineHasLanded = phase == .ready
            }
        }
    }

    // MARK: Uploading

    private var uploadNote: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Saving your conversation")
                .font(TypeScale.headline)
                .tracking(-0.4)
                .foregroundStyle(Palette.ink)
            Text("\(meeting.duration) recorded. Your notes are on their way.")
                .font(TypeScale.body)
                .foregroundStyle(Palette.inkSoft)
        }
    }

    // MARK: Summary

    private var written: some View {
        VStack(alignment: .leading, spacing: 28) {
            if step >= 1 {
                VStack(alignment: .leading, spacing: 10) {
                    CarriedPhraseLine(
                        text: summary.headline,
                        phrase: summary.headlineMark,
                        namespace: takeaway,
                        showsContext: headlineHasLanded || !isWriting || reduceMotion
                    )
                    // Reserve the final height while the date travels, then
                    // write the explanation beneath the settled headline.
                    Group {
                        if headlineHasLanded || !isWriting || reduceMotion {
                            Unfolding(text: summary.overview, animated: isWriting, color: Palette.inkSoft)
                        } else {
                            Text(summary.overview).hidden()
                        }
                    }
                    .font(TypeScale.lead)
                    .lineSpacing(5)
                }
                .transition(.identity)
            }

            if step >= 2 {
                VStack(alignment: .leading, spacing: 18) {
                    Hairline()
                    SectionHeading(title: "Key points")
                    ForEach(Array(summary.keyPoints.enumerated()), id: \.element.id) { index, point in
                        if step >= 2 + index {
                            if index > 0 {
                                Hairline()
                                    .transition(settle)
                            }
                            KeyPointRow(
                                point: point,
                                speakers: speakers(for: point),
                                isWriting: isWriting,
                                action: { onSource(point) }
                            )
                            .matchedTransitionSource(id: point.id, in: sources)
                            .transition(settle)
                        }
                    }
                }
                .transition(settle)
            }

            if step >= actionsStart {
                VStack(alignment: .leading, spacing: 14) {
                    Hairline()
                        .padding(.bottom, 4)
                    nextStepsHeading
                    ForEach(Array(summary.actions.enumerated()), id: \.element.id) { index, item in
                        if step >= actionsStart + index {
                            ActionRow(item: item, isDone: completed.contains(item.id)) {
                                withAnimation(reduceMotion ? nil : .spring(duration: 0.35, bounce: 0.3)) {
                                    if completed.contains(item.id) {
                                        completed.remove(item.id)
                                    } else {
                                        completed.insert(item.id)
                                    }
                                }
                            }
                            .transition(settle)
                        }
                    }
                }
                .transition(settle)
                .sensoryFeedback(.success, trigger: allDone) { _, done in done }
            }
        }
    }

    /// "Next steps", until every one of them is checked off.
    private var nextStepsHeading: some View {
        // Both states contribute their size so the seal never pushes tasks
        // down when the last item is completed, or up when it is reopened.
        ZStack(alignment: .leading) {
            SectionHeading(title: "Next steps")
                .opacity(allDone ? 0 : 1)
            HStack(spacing: 6) {
                Image(systemName: "checkmark.seal.fill")
                    .font(TypeScale.label)
                    .foregroundStyle(Palette.leaf)
                SectionHeading(title: "All done")
            }
            .opacity(allDone ? 1 : 0)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(allDone ? "All done" : "Next steps")
        .accessibilityAddTraits(.isHeader)
    }

    /// The people whose words a key point rests on, each listed once.
    private func speakers(for point: KeyPoint) -> [Speaker] {
        var seen: [Speaker] = []
        for line in point.sourceLines.compactMap(meeting.line) where !seen.contains(line.speaker) {
            seen.append(line.speaker)
        }
        return seen
    }
}

private struct SectionHeading: View {
    let title: String
    var body: some View {
        Text(title)
            .font(TypeScale.label)
            .foregroundStyle(Palette.inkSoft)
            .accessibilityAddTraits(.isHeader)
    }
}

/// A takeaway, marked with the same yellow that marks its source in the
/// transcript, and signed by the people who said it. Tapping it shows their words.
private struct KeyPointRow: View {
    let point: KeyPoint
    let speakers: [Speaker]
    let isWriting: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 5) {
                Text(point.title)
                    .font(TypeScale.section)
                    .foregroundStyle(Palette.ink)
                Unfolding(text: point.text, animated: isWriting)
                    .font(TypeScale.body)
                    .lineSpacing(4)
                if !speakers.isEmpty {
                    HStack(spacing: 7) {
                        HStack(spacing: -4) {
                            ForEach(speakers, id: \.self) { speaker in
                                SpeakerBadge(speaker: speaker, size: 18)
                                    .overlay { Circle().strokeBorder(Palette.paper, lineWidth: 1.5) }
                            }
                        }
                        Text(speakers.map(\.name).joined(separator: ", "))
                            .font(TypeScale.meta)
                            .foregroundStyle(Palette.sage)
                    }
                    .padding(.top, 4)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.trailing, 28)
            .overlay(alignment: .trailing) {
                // Says "there is more behind this" without turning it into a card.
                Image(systemName: "chevron.right")
                    .font(TypeScale.meta.weight(.semibold))
                    .foregroundStyle(Palette.sage)
                    .opacity(isWriting ? 0 : 1)
                    .accessibilityHidden(true)
            }
            .padding(.leading, 16)
            .overlay(alignment: .leading) {
                Capsule()
                    .fill(Palette.sun)
                    .frame(width: 3)
                    .padding(.vertical, 3)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(QuietButtonStyle())
        .allowsHitTesting(!isWriting)
        .accessibilityHint("Shows where this was said")
    }
}

private struct ActionRow: View {
    let item: ActionItem
    let isDone: Bool
    let toggle: () -> Void

    var body: some View {
        Button(action: toggle) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: isDone ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(isDone ? Palette.leaf : Palette.sage)
                    .contentTransition(.symbolEffect(.replace))
                    .symbolEffect(.bounce, value: isDone)
                VStack(alignment: .leading, spacing: 3) {
                    Text(item.task)
                        .font(TypeScale.body)
                        .foregroundStyle(isDone ? Palette.inkSoft : Palette.ink)
                        .strikethrough(isDone, color: Palette.leaf)
                        .fixedSize(horizontal: false, vertical: true)
                    ViewThatFits(in: .horizontal) {
                        HStack(spacing: 8) {
                            ownerLabel
                            if !item.due.isEmpty {
                                MetadataChip(text: item.due)
                            }
                        }
                        VStack(alignment: .leading, spacing: 6) {
                            ownerLabel
                            if !item.due.isEmpty {
                                MetadataChip(text: item.due)
                            }
                        }
                    }
                    .padding(.top, 2)
                }
                Spacer(minLength: 12)
            }
            .frame(minHeight: 44, alignment: .leading)
            .contentShape(Rectangle())
        }
        .buttonStyle(QuietButtonStyle())
        .sensoryFeedback(.selection, trigger: isDone)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(item.task), \(item.owner.name)\(item.due.isEmpty ? "" : ", \(item.due)")")
        .accessibilityValue(isDone ? "Completed" : "Not completed")
        .accessibilityAddTraits(.isButton)
    }

    private var ownerLabel: some View {
        HStack(spacing: 6) {
            SpeakerBadge(speaker: item.owner, size: 18)
            Text(item.owner.name)
                .font(TypeScale.meta)
                .foregroundStyle(Palette.sage)
                .fixedSize()
        }
    }
}
