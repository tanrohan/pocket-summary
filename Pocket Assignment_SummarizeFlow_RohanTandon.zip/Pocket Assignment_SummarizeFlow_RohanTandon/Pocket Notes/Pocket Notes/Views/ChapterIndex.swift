import SwiftUI
import Foundation

/// A quiet index at the edge of the transcript. The finger previews chapters;
/// only lifting it asks the transcript to move.
struct ChapterIndex: View {
    let chapters: [Chapter]
    let activeChapterID: String
    let onSelect: (String) -> Void

    @GestureState private var scrubY: CGFloat?
    @State private var labelHeight: CGFloat = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private let touchWidth: CGFloat = 44
    private let edgeInset: CGFloat = 12

    private var activeIndex: Int {
        chapters.firstIndex { $0.id == activeChapterID } ?? 0
    }

    var body: some View {
        GeometryReader { geometry in
            // In a short viewport, wait until the shared header scrolls away
            // rather than squeezing the index against the bottom tabs.
            if !chapters.isEmpty, geometry.size.height >= max(92, CGFloat(chapters.count) * 14 + 48) {
                let railHeight = min(CGFloat(chapters.count) * 22, max(44, geometry.size.height - 48))
                let slot = railHeight / CGFloat(chapters.count)
                let railTop = (geometry.size.height - railHeight) / 2
                let previewIndex = scrubY.map { index(at: $0, slot: slot) }
                let selectedIndex = previewIndex ?? activeIndex

                ZStack(alignment: .topLeading) {
                    rail(slot: slot, height: railHeight, selectedIndex: selectedIndex)
                        .position(x: geometry.size.width - touchWidth / 2, y: geometry.size.height / 2)

                    if let scrubY, let previewIndex {
                        let labelWidth = min(250, max(1, geometry.size.width - 74))
                        chapterLabel(chapters[previewIndex], index: previewIndex)
                            .frame(width: labelWidth, alignment: .leading)
                            .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { labelHeight = $0 }
                            .position(
                                x: geometry.size.width - 60 - labelWidth / 2,
                                y: labelCenter(railTop + scrubY, in: geometry.size.height)
                            )
                            .transition(.opacity)
                            .allowsHitTesting(false)
                            .accessibilityHidden(true)
                    }
                }
                .animation(reduceMotion ? nil : .spring(duration: 0.3, bounce: 0.14), value: scrubY == nil)
                .sensoryFeedback(.selection, trigger: previewIndex) { old, new in
                    new != nil && old != new
                }
            }
        }
    }

    private func rail(slot: CGFloat, height: CGFloat, selectedIndex: Int) -> some View {
        ZStack(alignment: .topLeading) {
            ForEach(Array(chapters.enumerated()), id: \.element.id) { index, _ in
                let center = (CGFloat(index) + 0.5) * slot
                let influence = influence(at: center, slot: slot)
                let selected = index == selectedIndex
                let width: CGFloat = scrubY == nil ? (selected ? 16 : 9) : 10 + 26 * influence

                Capsule()
                    .fill(selected ? Palette.leaf : Palette.sage.opacity(0.5 + 0.3 * influence))
                    .frame(width: width, height: scrubY == nil ? 3 : 3 + 2 * influence)
                    // Fixed centers and right edges keep targets still while
                    // the left ends form the curve around the finger.
                    .position(x: touchWidth - edgeInset - width / 2, y: center)
            }
        }
        .frame(width: touchWidth, height: height)
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .updating($scrubY) { value, state, _ in
                    state = min(max(value.location.y, slot / 2), height - slot / 2)
                }
                .onEnded { value in
                    onSelect(chapters[index(at: value.location.y, slot: slot)].id)
                }
        )
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Chapters")
        .accessibilityValue(accessibilityValue)
        .accessibilityHint("Swipe up or down to jump between chapters.")
        .accessibilityAdjustableAction { direction in
            let next: Int
            switch direction {
            case .increment: next = min(activeIndex + 1, chapters.count - 1)
            case .decrement: next = max(activeIndex - 1, 0)
            @unknown default: return
            }
            guard next != activeIndex else { return }
            onSelect(chapters[next].id)
        }
        .accessibilityAction {
            onSelect(chapters[activeIndex].id)
        }
        .accessibilityAction(named: Text("First chapter")) {
            if let first = chapters.first { onSelect(first.id) }
        }
        .accessibilityAction(named: Text("Last chapter")) {
            if let last = chapters.last { onSelect(last.id) }
        }
    }

    private func chapterLabel(_ chapter: Chapter, index: Int) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(chapter.title)
                .font(TypeScale.label)
                .foregroundStyle(Palette.ink)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                if let time = chapter.lines.first?.time {
                    Text(time)
                        .monospacedDigit()
                }
                Text("\(index + 1) of \(chapters.count)")
            }
            .font(TypeScale.meta)
            .foregroundStyle(Palette.inkSoft)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassEffect(.regular, in: .rect(cornerRadius: 16))
    }

    private var accessibilityValue: String {
        guard !chapters.isEmpty else { return "No chapters" }
        let chapter = chapters[activeIndex]
        let time = chapter.lines.first.map { ", \($0.time)" } ?? ""
        return "\(chapter.title)\(time), chapter \(activeIndex + 1) of \(chapters.count)"
    }

    private func index(at y: CGFloat, slot: CGFloat) -> Int {
        min(max(Int(floor(y / max(slot, 1))), 0), chapters.count - 1)
    }

    private func influence(at y: CGFloat, slot: CGFloat) -> CGFloat {
        guard let scrubY else { return 0 }
        let distance = (y - scrubY) / max(slot * 1.25, 1)
        return exp(-0.5 * distance * distance)
    }

    private func labelCenter(_ y: CGFloat, in height: CGFloat) -> CGFloat {
        let half = min(labelHeight / 2 + 8, height / 2)
        return min(max(y, half), max(half, height - half))
    }
}
