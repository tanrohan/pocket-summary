import SwiftUI

/// The meeting's title, when it happened and for how long, and who was there.
struct MeetingHeader: View {
    let meeting: Meeting

    private var names: String {
        meeting.participants.map(\.name).joined(separator: ", ")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(meeting.title)
                .font(TypeScale.title)
                .tracking(-0.4)
                .lineLimit(2)
                .minimumScaleFactor(0.8)
                .foregroundStyle(Palette.ink)
                .accessibilityAddTraits(.isHeader)

            // Duration stays with the date, wrapping below when space is tight.
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(meeting.date).fixedSize()
                    MetadataChip(text: meeting.duration)
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text(meeting.date)
                    MetadataChip(text: meeting.duration)
                }
            }
            .font(TypeScale.subhead)
            .foregroundStyle(Palette.inkSoft)
            .padding(.top, 8)

            HStack(spacing: 8) {
                HStack(spacing: -5) {
                    ForEach(meeting.participants, id: \.self) { speaker in
                        SpeakerBadge(speaker: speaker, size: 22)
                            .overlay { Circle().strokeBorder(Palette.paper, lineWidth: 1.5) }
                    }
                }
                Text(names)
                    .font(TypeScale.subhead)
                    .foregroundStyle(Palette.inkSoft)
            }
            .padding(.top, 16)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Participants: \(names)")
        }
        .padding(.horizontal, 24)
        .padding(.top, 4)
        .padding(.bottom, 26)
        .frame(maxWidth: 620, alignment: .leading)
        .frame(maxWidth: .infinity)
    }
}
