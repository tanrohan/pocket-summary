import SwiftUI

/// The two ways to read a meeting.
enum MeetingTab: String, CaseIterable {
    case summary = "Summary"
    case transcript = "Transcript"
}

/// The one floating control. It reports progress while the meeting is
/// processed, then stretches into the switch between summary and transcript:
/// the pulsing green dot grows into the selected tab.
struct BottomBar: View {
    let phase: MeetingProcessor.Phase
    let uploadProgress: Double
    @Binding var tab: MeetingTab
    @Namespace private var glass
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Group {
            if phase == .ready {
                ModeSwitch(tab: $tab, glass: glass)
                    .transition(.opacity)
            } else {
                StatusPill(phase: phase, uploadProgress: uploadProgress, glass: glass)
                    .transition(.opacity)
            }
        }
        .padding(4)
        .glassEffect(.regular.interactive(), in: .capsule)
        .padding(.bottom, 8)
        .animation(reduceMotion ? nil : .spring(duration: 0.6, bounce: 0.25), value: phase == .ready)
    }
}

private struct StatusPill: View {
    let phase: MeetingProcessor.Phase
    let uploadProgress: Double
    let glass: Namespace.ID
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(Palette.leaf)
                .matchedGeometryEffect(id: "live", in: glass)
                .frame(width: 8, height: 8)
                .phaseAnimator([1.0, 0.35]) { dot, opacity in
                    dot.opacity(reduceMotion ? 1 : opacity)
                } animation: { _ in
                    .easeInOut(duration: 0.9)
                }

            Text(title)
                .font(TypeScale.label)
                .foregroundStyle(Palette.ink)
                .contentTransition(.opacity)

            if phase == .uploading {
                Text("\(Int(uploadProgress * 100))%")
                    .font(TypeScale.meta)
                    .monospacedDigit()
                    .foregroundStyle(Palette.inkSoft)
                    .contentTransition(.numericText())
            }
        }
        .padding(.horizontal, 18)
        .frame(height: 44)
        .accessibilityElement(children: .combine)
    }

    private var title: String {
        switch phase {
        case .uploading: "Uploading"
        case .transcribing: "Transcribing"
        case .distilling: "Finding what matters"
        case .summarizing: "Writing summary"
        case .ready: "Ready"
        }
    }
}

private struct ModeSwitch: View {
    @Binding var tab: MeetingTab
    let glass: Namespace.ID
    @Namespace private var selection
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        HStack(spacing: 0) {
            ForEach(MeetingTab.allCases, id: \.self) { item in
                Button {
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.3)) { tab = item }
                } label: {
                    Text(item.rawValue)
                        .font(TypeScale.label)
                        .foregroundStyle(tab == item ? Palette.onLeaf : Palette.ink)
                        .padding(.horizontal, 22)
                        .frame(height: 44)
                        .background {
                            if tab == item {
                                Capsule()
                                    .fill(Palette.leaf)
                                    .matchedGeometryEffect(id: "mode", in: selection)
                                    .matchedGeometryEffect(id: "live", in: glass)
                            }
                        }
                        .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(tab == item ? .isSelected : [])
            }
        }
        .sensoryFeedback(.selection, trigger: tab)
    }
}
