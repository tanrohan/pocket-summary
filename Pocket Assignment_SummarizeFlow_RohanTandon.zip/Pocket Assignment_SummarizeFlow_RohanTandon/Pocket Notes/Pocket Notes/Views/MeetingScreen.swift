import SwiftUI

/// The single screen. It holds two panes, summary and transcript, each with
/// its own scroll position, under one floating control.
struct MeetingScreen: View {
    @State private var processor = MeetingProcessor(meeting: .atlasLaunchReview)
    @State private var tab: MeetingTab = .summary
    @State private var completed: Set<Int> = []
    /// The transcript line a tapped quote leads to, while it is spotlit.
    @State private var focusedLine: Int?
    @State private var focusRequest = UUID()
    /// The key point whose source moments are showing in the sheet.
    @State private var openPoint: KeyPoint?
    /// Whether each pane has scrolled its large title out of view.
    @State private var summaryScrolled = false
    @State private var transcriptScrolled = false
    @State private var visibleTranscriptLines: Set<Int> = []
    @State private var activeChapterID: String?
    @State private var metadataHeight: CGFloat = 0
    @State private var transcriptRibbonHeight: CGFloat = 0
    @State private var transcriptViewportHeight: CGFloat = 1
    @State private var transcriptTopInset: CGFloat = 0
    @State private var transcriptBottomInset: CGFloat = 0
    @State private var transcriptIsAtBottom = false
    @State private var summaryOffset: CGFloat = 0
    /// Where the top section (title through recording) ends in each pane,
    /// measured from the top of the screen. The top wash fades out there.
    @State private var summarySectionBottom: CGFloat = 0
    @State private var transcriptSectionBottom: CGFloat = 0
    @State private var transcriptOffset: CGFloat = 0
    @State private var readingPosition: Double = 0
    /// Once the reader scrolls, generation leaves their position alone.
    @State private var readerControlsScroll = false
    @State private var replayID = UUID()
    @State private var hasStarted = false
    @Namespace private var sources
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var meeting: Meeting { processor.meeting }
    private var isReady: Bool { processor.phase == .ready }
    private var showsBarTitle: Bool { tab == .summary ? summaryScrolled : transcriptScrolled }
    private var sectionBottom: CGFloat { tab == .summary ? summarySectionBottom : transcriptSectionBottom }

    private static let top = "top"
    private static let tail = "tail"

    private struct FollowRequest: Equatable {
        let phase: MeetingProcessor.Phase
        let visibleLines: Int
        let readerControlsScroll: Bool
    }

    private struct TranscriptScrollState: Equatable {
        let isPastTitle: Bool
        let headerOffset: CGFloat
        let viewportHeight: CGFloat
        let topInset: CGFloat
        let bottomInset: CGFloat
        let isAtBottom: Bool
    }

    private var followRequest: FollowRequest {
        FollowRequest(
            phase: processor.phase,
            visibleLines: processor.visibleLines,
            readerControlsScroll: readerControlsScroll
        )
    }

    var body: some View {
        // Separate scroll views: a transcript offset is never applied to the
        // shorter summary, and returning to a tab restores the reader's place.
        ZStack(alignment: .top) {
            summaryPane
                .opacity(tab == .summary ? 1 : 0)
                .allowsHitTesting(tab == .summary)
                .accessibilityHidden(tab != .summary)
                .zIndex(tab == .summary ? 1 : 0)
            if isReady {
                transcriptPane
                    .opacity(tab == .transcript ? 1 : 0)
                    .allowsHitTesting(tab == .transcript)
                    .accessibilityHidden(tab != .transcript)
                    .zIndex(tab == .transcript ? 1 : 0)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            BottomBar(phase: processor.phase, uploadProgress: processor.uploadProgress, tab: $tab)
                // Step aside while a sheet is up, so it never shows through the glass.
                .opacity(openPoint == nil ? 1 : 0)
                .animation(.easeOut(duration: 0.2), value: openPoint == nil)
        }
        // A quiet top bar keeps the compact title and recording clear of
        // transcript text as it passes underneath.
        .safeAreaBar(edge: .top, spacing: 0) {
            topBar
        }
        .background(TopWash(bottom: sectionBottom).ignoresSafeArea())
        .sheet(item: $openPoint) { point in
            SourceSheet(point: point, lines: point.sourceLines.compactMap(meeting.line)) { line in
                openPoint = nil
                showSource(line)
            }
            // The sheet grows out of the key point that was tapped.
            .navigationTransition(.zoom(sourceID: point.id, in: sources))
        }
        .sensoryFeedback(.success, trigger: isReady) { _, ready in ready }
        .task {
            guard !hasStarted else { return }
            hasStarted = true
            processor.start(reduceMotion: reduceMotion)
        }
        .onDisappear {
            processor.stop()
            hasStarted = false
        }
        .onChange(of: tab) { _, newValue in
            // Leaving the transcript ends any spotlight, so it is never waiting
            // there on the way back.
            if newValue == .summary { focusedLine = nil }
        }
        .onChange(of: reduceMotion) { _, newValue in
            processor.setReduceMotion(newValue)
        }
    }

    // MARK: Top bar

    /// The meeting title settles here, as plain text, once the large one
    /// scrolls away. The round button is the demo control.
    private var topBar: some View {
        HStack(spacing: 10) {
            if showsBarTitle {
                Text(meeting.title)
                    .font(TypeScale.label)
                    .foregroundStyle(Palette.ink)
                    .lineLimit(1)
                    .frame(height: 44)
                    .transition(.settle(reduceMotion: reduceMotion))
                    .accessibilityHidden(true)
            }
            Spacer(minLength: 0)
            controlButton
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 4)
        .background(TopWash(bottom: sectionBottom).ignoresSafeArea(edges: .top))
        .animation(reduceMotion ? nil : .smooth(duration: 0.3), value: showsBarTitle)
    }

    /// Replays the experience when ready, skips to the end otherwise.
    private var controlButton: some View {
        Button(action: control) {
            Image(systemName: isReady ? "arrow.counterclockwise" : "forward.end.fill")
                .font(isReady ? .system(.title2, weight: .semibold) : .system(.subheadline, weight: .medium))
                .foregroundStyle(Palette.ink)
                .contentTransition(.symbolEffect(.replace))
                .frame(width: 22, height: 22)
        }
        .buttonStyle(.glass)
        .buttonBorderShape(.circle)
        .controlSize(.large)
        .accessibilityLabel(isReady ? "Replay processing" : "Skip to summary")
    }

    // MARK: Panes

    /// The title, date, and participants. Its height tells each pane when the
    /// recording beneath it has become pinned.
    private var header: some View {
        MeetingHeader(meeting: meeting)
            .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { metadataHeight = $0 }
    }

    /// The same ribbon starts below the meeting details and pins naturally
    /// beneath the top bar as those details leave the viewport.
    private func recordingHeader(in transcript: Bool) -> some View {
        RecordingRibbon(
            meeting: meeting,
            progress: ribbonProgress,
            height: processor.phase == .uploading ? 104 : 24,
            showsMarks: processor.phase >= .summarizing,
            readingPosition: transcript ? readingPosition : nil,
            labelBelow: (transcript ? transcriptOffset : summaryOffset) >= metadataHeight - 1,
            onScrub: isReady ? { showSource($0) } : nil
        )
        .padding(.horizontal, 24)
        .padding(.top, processor.phase == .uploading ? 30 : 6)
        .padding(.bottom, processor.phase == .uploading ? 26 : 16)
        .frame(maxWidth: 620)
        .frame(maxWidth: .infinity)
        .background(TopWash(bottom: transcript ? transcriptSectionBottom : summarySectionBottom))
        .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).maxY } action: { newBottom in
            if transcript {
                transcriptSectionBottom = newBottom
            } else {
                summarySectionBottom = newBottom
            }
        }
    }

    private var ribbonProgress: Double {
        switch processor.phase {
        case .uploading: processor.uploadProgress
        case .transcribing: processor.transcriptionProgress
        case .distilling, .summarizing, .ready: 1
        }
    }

    private var summaryPane: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 0) {
                    header
                        .id(Self.top)
                    Section {
                        SummaryView(
                            processor: processor,
                            completed: $completed,
                            sources: sources,
                            onSource: { openPoint = $0 }
                        )
                        .padding(.horizontal, 24)
                        .padding(.bottom, 28)
                        .frame(maxWidth: 620)
                        .frame(maxWidth: .infinity)
                        Color.clear
                            .frame(height: 1)
                            .id(Self.tail)
                    } header: {
                        recordingHeader(in: false)
                    }
                }
            }
            .scrollIndicators(.hidden)
            .scrollEdgeEffectStyle(.soft, for: .top)
            .defaultScrollAnchor(.top)
            .onScrollGeometryChange(for: CGFloat.self) { geometry in
                min(max(geometry.contentOffset.y + geometry.contentInsets.top, 0), metadataHeight)
            } action: { _, offset in
                summaryScrolled = offset > 64
                summaryOffset = offset
            }
            .onScrollPhaseChange { _, phase in
                if phase == .interacting {
                    readerControlsScroll = true
                }
            }
            // Follow the live transcript only until the reader takes control.
            // Appending summary sections never moves the headline offscreen.
            .task(id: followRequest) {
                guard processor.phase == .transcribing, !readerControlsScroll else { return }
                let currentReplay = replayID
                let currentLineCount = processor.visibleLines
                do {
                    // Let the new line take its place in the layout first.
                    try await Task.sleep(for: .milliseconds(60))
                } catch {
                    return
                }
                guard !Task.isCancelled,
                      processor.phase == .transcribing,
                      !readerControlsScroll,
                      replayID == currentReplay,
                      processor.visibleLines == currentLineCount else { return }
                withAnimation(reduceMotion ? nil : .smooth(duration: 0.6)) {
                    proxy.scrollTo(Self.tail, anchor: .bottom)
                }
            }
            .onChange(of: processor.phase) { _, phase in
                // The transcript distils at the top of the page, where the
                // summary is about to be written. A reader's position wins.
                guard phase == .distilling, !readerControlsScroll else { return }
                withAnimation(reduceMotion ? nil : .smooth(duration: 0.8)) {
                    proxy.scrollTo(Self.top, anchor: .top)
                }
            }
        }
        .id(replayID)
    }

    private var transcriptPane: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 0, pinnedViews: [.sectionHeaders]) {
                    header
                    Section {
                        FullTranscript(
                            chapters: meeting.chapters,
                            highlighted: processor.highlighted,
                            focusedLine: focusedLine,
                            // The named viewport begins below the top inset.
                            visibleTop: transcriptRibbonHeight,
                            visibleBottom: max(transcriptRibbonHeight, transcriptViewportHeight - transcriptTopInset - transcriptBottomInset),
                            onLineVisibilityChange: trackTranscriptLine
                        )
                        .padding(.leading, 24)
                        .padding(.trailing, 44)
                        .padding(.bottom, 30)
                        .frame(maxWidth: 620)
                        .frame(maxWidth: .infinity)
                    } header: {
                        recordingHeader(in: true)
                            .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { transcriptRibbonHeight = $0 }
                    }
                }
            }
            .coordinateSpace(name: "transcriptViewport")
            .scrollIndicators(.hidden)
            .scrollEdgeEffectStyle(.soft, for: .top)
            .defaultScrollAnchor(.top)
            .onScrollGeometryChange(for: TranscriptScrollState.self) { geometry in
                let offset = geometry.contentOffset.y + geometry.contentInsets.top
                return TranscriptScrollState(
                    isPastTitle: offset > 64,
                    headerOffset: min(max(offset, 0), metadataHeight),
                    viewportHeight: max(1, geometry.containerSize.height),
                    topInset: geometry.contentInsets.top,
                    bottomInset: geometry.contentInsets.bottom,
                    isAtBottom: geometry.visibleRect.maxY >= geometry.contentSize.height - 1
                )
            } action: { _, state in
                transcriptScrolled = state.isPastTitle
                transcriptOffset = state.headerOffset
                transcriptViewportHeight = state.viewportHeight
                transcriptTopInset = state.topInset
                transcriptBottomInset = state.bottomInset
                transcriptIsAtBottom = state.isAtBottom
                updateReadingPosition()
            }
            .onScrollPhaseChange { _, phase in
                if phase == .interacting {
                    focusedLine = nil
                    focusRequest = UUID()
                    updateReadingPosition()
                }
            }
            .overlay {
                ChapterIndex(
                    chapters: meeting.chapters,
                    activeChapterID: activeChapterID ?? meeting.chapters.first?.id ?? ""
                ) { chapterID in
                    // A chapter choice supersedes any pending source spotlight.
                    focusedLine = nil
                    focusRequest = UUID()
                    activeChapterID = chapterID
                    if let first = meeting.chapters.first(where: { $0.id == chapterID })?.lines.first,
                       let position = meeting.fraction(for: first.id) {
                        readingPosition = position
                    }
                    // Scrubbing only previews; the transcript moves on release.
                    // A direct jump avoids flying through hundreds of lazy rows.
                    withAnimation(nil) {
                        let anchor = min(max(transcriptRibbonHeight / max(transcriptViewportHeight - 1, 1), 0), 1)
                        proxy.scrollTo(chapterID, anchor: UnitPoint(x: 0.5, y: anchor))
                    }
                }
                .padding(.top, max(0, metadataHeight - transcriptOffset) + transcriptRibbonHeight)
                .padding(.bottom, 16)
            }
            .onChange(of: visibleTranscriptLines) { _, lines in
                guard let first = lines.min(),
                      let chapter = meeting.chapters.first(where: { chapter in
                          chapter.lines.contains { $0.id == first }
                      }) else { return }
                activeChapterID = chapter.id
                updateReadingPosition()
            }
            .task(id: focusRequest) {
                guard tab == .transcript, let target = focusedLine else { return }
                // Let the pane appear, then bring the line to the middle of the
                // screen. A newer tap or a replay cancels this task.
                await Task.yield()
                guard !Task.isCancelled else { return }
                proxy.scrollTo(target, anchor: .center)
                // The glow marks the spot, then lets go. Nothing stays behind.
                try? await Task.sleep(for: .seconds(2.4))
                guard !Task.isCancelled else { return }
                withAnimation(reduceMotion ? nil : .easeOut(duration: 0.9)) {
                    focusedLine = nil
                }
            }
        }
    }

    // MARK: Behavior

    private func trackTranscriptLine(_ id: Int, isVisible: Bool) {
        if isVisible {
            visibleTranscriptLines.insert(id)
        } else {
            visibleTranscriptLines.remove(id)
        }
    }

    private func updateReadingPosition() {
        guard focusedLine == nil else { return }
        if transcriptOffset < metadataHeight {
            readingPosition = 0
        } else if transcriptIsAtBottom {
            readingPosition = 1
        } else if let first = visibleTranscriptLines.min(),
                  let position = meeting.fraction(for: first) {
            readingPosition = position
        }
    }

    /// Opens the transcript at the moment a quote came from.
    private func showSource(_ id: Int) {
        guard isReady, meeting.line(id) != nil else { return }
        focusedLine = id
        readingPosition = meeting.fraction(for: id) ?? 0
        withAnimation(reduceMotion ? nil : .snappy(duration: 0.3)) {
            tab = .transcript
        }
        focusRequest = UUID()
    }

    /// The demo control: skip to the finished summary, or replay from the start.
    private func control() {
        tab = .summary
        openPoint = nil
        focusedLine = nil
        focusRequest = UUID()
        summaryScrolled = false
        transcriptScrolled = false
        visibleTranscriptLines = []
        activeChapterID = nil
        transcriptOffset = 0
        summaryOffset = 0
        readingPosition = 0
        transcriptIsAtBottom = false
        readerControlsScroll = false
        replayID = UUID()
        if isReady {
            completed = []
            processor.start(reduceMotion: reduceMotion)
        } else {
            processor.finish()
        }
    }
}

#Preview {
    MeetingScreen()
        .fontDesign(.serif)
}
