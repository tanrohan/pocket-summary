import SwiftUI

/// The words behind a key point. Every moment it draws on is shown together,
/// so there is nothing to page through. Tapping one opens it in the transcript.
struct SourceSheet: View {
    let point: KeyPoint
    let lines: [TranscriptLine]
    let onOpen: (Int) -> Void

    @State private var isMarked = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("From the conversation")
                        .font(TypeScale.label)
                        .foregroundStyle(Palette.inkSoft)
                    Text(point.title)
                        .font(TypeScale.headline)
                        .tracking(-0.4)
                        .foregroundStyle(Palette.ink)
                        .accessibilityAddTraits(.isHeader)
                }

                ForEach(lines) { line in
                    Button {
                        onOpen(line.id)
                    } label: {
                        VStack(alignment: .leading, spacing: 9) {
                            HStack(spacing: 8) {
                                SpeakerBadge(speaker: line.speaker)
                                Text(line.speaker.name)
                                    .font(TypeScale.label)
                                    .foregroundStyle(Palette.ink)
                                Spacer(minLength: 8)
                                Image(systemName: "arrow.up.right")
                                    .font(TypeScale.meta.weight(.semibold))
                                    .foregroundStyle(Palette.sage)
                                    .accessibilityHidden(true)
                            }
                            HighlightedText(text: line.text, phrase: line.highlight, sweep: isMarked ? 1 : 0)
                                .font(TypeScale.transcript)
                                .lineSpacing(4)
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(QuietButtonStyle())
                    .accessibilityHint("Opens this moment in the transcript")
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 30)
            .padding(.bottom, 24)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .task {
            // The highlighter sweeps across each quote once the sheet has settled.
            guard !reduceMotion else {
                isMarked = true
                return
            }
            try? await Task.sleep(for: .milliseconds(350))
            withAnimation(.easeOut(duration: 0.8)) { isMarked = true }
        }
    }
}
