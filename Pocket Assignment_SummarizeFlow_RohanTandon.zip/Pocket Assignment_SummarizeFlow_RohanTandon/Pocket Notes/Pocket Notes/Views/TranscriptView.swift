import SwiftUI

/// A person's color and initial. The same badge marks them everywhere.
struct SpeakerBadge: View {
    let speaker: Speaker
    var size: CGFloat = 24

    var body: some View {
        Text(String(speaker.name.prefix(1)))
            .font(.system(size: size * 0.5, weight: .semibold))
            .foregroundStyle(Palette.badgeInk)
            .frame(width: size, height: size)
            .background(speaker.tint, in: Circle())
            .accessibilityHidden(true)
    }
}

/// Who is speaking and when: badge, name, and timestamp.
struct SpeakerLabel: View {
    let speaker: Speaker
    let time: String

    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            SpeakerBadge(speaker: speaker)
            Text(speaker.name).font(TypeScale.label).foregroundStyle(Palette.ink)
            Text(time).font(TypeScale.meta).monospacedDigit().foregroundStyle(Palette.sage)
        }
        .accessibilityElement(children: .combine)
    }
}

/// The conversation as it is transcribed. Lines build up one at a time, older
/// ones receding. When transcription ends the lines distil: everything fades
/// except the highlighted phrases, which gather into the raw material of the
/// summary.
struct LiveTranscript: View {
    let lines: [TranscriptLine]
    let highlighted: Set<Int>
    let isDistilling: Bool
    let headlineMark: String
    let takeaway: Namespace.ID

    private enum Stage {
        /// Lines are arriving and can be read in full.
        case reading
        /// Only the highlighted phrases are left, still in place.
        case essence
        /// The phrases have drawn together into a short stack.
        case gathered
    }

    @State private var stage = Stage.reading
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Group {
            if stage == .gathered {
                gathered
                    // Removal must not offset or blur the shared date while
                    // matched geometry carries it into the headline.
                    .transition(.asymmetric(insertion: .settle(reduceMotion: reduceMotion), removal: .opacity))
            } else {
                rows
                    .transition(.settle(reduceMotion: reduceMotion))
            }
        }
        .task(id: isDistilling) {
            guard isDistilling else { return }
            guard !reduceMotion else {
                stage = .gathered
                return
            }
            withAnimation(.easeInOut(duration: 0.9)) { stage = .essence }
            try? await Task.sleep(for: .seconds(1.1))
            guard !Task.isCancelled else { return }
            withAnimation(.smooth(duration: 0.8)) { stage = .gathered }
        }
    }

    private var rows: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(lines.enumerated()), id: \.element.id) { index, line in
                TranscriptRow(
                    line: line,
                    isMarked: highlighted.contains(line.id),
                    isFocused: false,
                    distill: stage == .reading ? 0 : 1
                )
                .opacity(stage == .reading && index < lines.count - 2 ? 0.45 : 1)
                .transition(.settle(reduceMotion: reduceMotion))
            }
        }
    }

    private var gathered: some View {
        VStack(alignment: .leading, spacing: 14) {
            if let decision = lines.first(where: { $0.highlight?.contains(headlineMark) == true }),
               let phrase = decision.highlight {
                VStack(alignment: .leading, spacing: 9) {
                    SpeakerLabel(speaker: decision.speaker, time: decision.time)
                    CarriedPhraseLine(text: phrase, phrase: headlineMark, namespace: takeaway)
                }
                .padding(.bottom, 8)
            }
            ForEach(lines) { line in
                if let phrase = line.highlight, !phrase.contains(headlineMark) {
                    HighlightedText(text: phrase, phrase: phrase, sweep: 1)
                        .font(TypeScale.lead)
                }
            }
        }
        .padding(.top, 14)
    }
}

/// The whole conversation, grouped by topic.
struct FullTranscript: View {
    let chapters: [Chapter]
    let highlighted: Set<Int>
    /// The line a key point just led to. It glows briefly, then settles.
    let focusedLine: Int?
    /// The reading area excludes the pinned recording above it.
    let visibleTop: CGFloat
    let visibleBottom: CGFloat
    /// Visible rows identify the chapter even while lazy headers are offscreen.
    let onLineVisibilityChange: (Int, Bool) -> Void

    var body: some View {
        LazyVStack(alignment: .leading, spacing: 0) {
            ForEach(chapters) { chapter in
                Section {
                    ForEach(chapter.lines) { line in
                        TranscriptRow(line: line, isMarked: highlighted.contains(line.id), isFocused: focusedLine == line.id)
                            .id(line.id)
                            .onGeometryChange(for: Bool.self) { proxy in
                                let frame = proxy.frame(in: .named("transcriptViewport"))
                                return frame.maxY > visibleTop + 1 && frame.minY < visibleBottom
                            } action: { _, isVisible in
                                onLineVisibilityChange(line.id, isVisible)
                            }
                            .onDisappear { onLineVisibilityChange(line.id, false) }
                    }
                } header: {
                    VStack(alignment: .leading, spacing: 0) {
                        // A stable, one-point target lets chapter jumps clear
                        // the recording pinned above the reading area.
                        Color.clear
                            .frame(height: 1)
                            .id(chapter.id)
                        VStack(alignment: .leading, spacing: 22) {
                            if chapter.id != chapters.first?.id {
                                Hairline()
                            }
                            Text(chapter.title)
                                .font(TypeScale.chapter)
                                .tracking(-0.3)
                                .foregroundStyle(Palette.ink)
                                .fixedSize(horizontal: false, vertical: true)
                                .accessibilityAddTraits(.isHeader)
                        }
                        .padding(.top, chapter.id == chapters.first?.id ? 8 : 18)
                        .padding(.bottom, 8)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
    }
}

private struct TranscriptRow: View {
    let line: TranscriptLine
    let isMarked: Bool
    let isFocused: Bool
    /// 1 leaves only the highlighted phrase visible. See `LiveTranscript`.
    var distill: Double = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            SpeakerLabel(speaker: line.speaker, time: line.time)
                .opacity(1 - distill)
            HighlightedText(text: line.text, phrase: line.highlight, sweep: isMarked ? 1 : 0, distill: distill)
                .font(TypeScale.transcript)
                .lineSpacing(4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(isFocused ? Palette.sun.opacity(0.22) : .clear)
        }
        .padding(.horizontal, -14)
        .accessibilityElement(children: .combine)
    }
}
