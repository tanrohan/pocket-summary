import SwiftUI
import Foundation

/// The highlighted words remain a shared visual object as the quote becomes
/// the headline. Surrounding words can fade in after the phrase has landed.
struct CarriedPhraseLine: View {
    let text: String
    let phrase: String
    let namespace: Namespace.ID
    var showsContext = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Group {
            if let range = text.range(of: phrase) {
                PhraseLineLayout {
                    Text(String(text[..<range.lowerBound]).trimmingCharacters(in: .whitespaces))
                        .opacity(showsContext ? 1 : 0)
                    HStack(alignment: .firstTextBaseline, spacing: 0) {
                        if reduceMotion {
                            markedWords
                        } else {
                            markedWords
                                .matchedGeometryEffect(id: "takeaway-phrase", in: namespace)
                        }
                        Text(String(text[range.upperBound...]))
                            .opacity(showsContext ? 1 : 0)
                    }
                }
            } else {
                Text(text)
            }
        }
        .font(TypeScale.headline)
        .tracking(-0.4)
        .foregroundStyle(Palette.ink)
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(text)
    }

    private var markedWords: some View {
        Text(phrase)
            .background(Palette.marker)
    }
}

/// Treats the date and its suffix as one layout item, allowing it to move to
/// the next line without creating duplicate matched views.
private struct PhraseLineLayout: Layout {
    private let wordGap: CGFloat = 5
    private let lineGap: CGFloat = 3

    private func placement(width: CGFloat?, subviews: Subviews) -> (sizes: [CGSize], wraps: Bool) {
        let limit = max(width ?? .greatestFiniteMagnitude, 1)
        let sizes = subviews.map { $0.sizeThatFits(ProposedViewSize(width: limit, height: nil)) }
        let wraps = sizes.reduce(0) { $0 + $1.width } + wordGap > limit
        return (sizes, wraps)
    }

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let result = placement(width: proposal.width, subviews: subviews)
        guard result.sizes.count == 2 else { return .zero }
        if result.wraps {
            return CGSize(width: result.sizes.map(\.width).max() ?? 0,
                          height: result.sizes.reduce(0) { $0 + $1.height } + lineGap)
        }
        return CGSize(width: result.sizes.reduce(0) { $0 + $1.width } + wordGap,
                      height: result.sizes.map(\.height).max() ?? 0)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = placement(width: bounds.width, subviews: subviews)
        guard result.sizes.count == 2 else { return }
        subviews[0].place(at: bounds.origin, anchor: .topLeading, proposal: ProposedViewSize(result.sizes[0]))
        let second = result.wraps
            ? CGPoint(x: bounds.minX, y: bounds.minY + result.sizes[0].height + lineGap)
            : CGPoint(x: bounds.minX + result.sizes[0].width + wordGap, y: bounds.minY)
        subviews[1].place(at: second, anchor: .topLeading, proposal: ProposedViewSize(result.sizes[1]))
    }
}

/// Sweeps a highlighter stroke across `phrase`, as far as `sweep` (0 to 1).
private func applyMarker(to text: inout AttributedString, phrase: String?, sweep: Double) {
    guard let phrase, sweep > 0, let range = text.range(of: phrase) else { return }
    let length = text.characters.distance(from: range.lowerBound, to: range.upperBound)
    let marked = Int((Double(length) * min(sweep, 1)).rounded())
    guard marked > 0 else { return }
    let end = text.characters.index(range.lowerBound, offsetBy: marked)
    text[range.lowerBound..<end].backgroundColor = Palette.marker
}

/// A soft wave of words with the final layout reserved from the first frame,
/// so nothing reflows as it appears.
struct RevealText: View, Animatable {
    let text: String
    var progress: Double
    var color: Color = Palette.ink

    var animatableData: Double {
        get { progress }
        set { progress = newValue }
    }

    var body: some View {
        Text(attributed)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
    }

    private var attributed: AttributedString {
        let chunks = wordChunks
        let feather = 3.0
        let head = min(max(progress, 0), 1) * (Double(chunks.count) + feather)
        var result = AttributedString()
        for (index, chunk) in chunks.enumerated() {
            var piece = AttributedString(chunk)
            let alpha = min(max((head - Double(index)) / feather, 0), 1)
            piece.foregroundColor = color.opacity(alpha)
            result.append(piece)
        }
        return result
    }

    /// Keeps whitespace exactly as authored, so the reveal never changes
    /// where lines wrap.
    private var wordChunks: [String] {
        var chunks: [String] = []
        var current = ""
        var hasWord = false
        var endedWithSpace = false
        for character in text {
            if !character.isWhitespace && hasWord && endedWithSpace {
                chunks.append(current)
                current = ""
                hasWord = false
            }
            current.append(character)
            hasWord = hasWord || !character.isWhitespace
            endedWithSpace = character.isWhitespace
        }
        if !current.isEmpty { chunks.append(current) }
        return chunks
    }
}

/// Reveals its text once, when it first appears. Skipping, or Reduce Motion,
/// shows the complete text immediately.
struct Unfolding: View {
    let text: String
    var animated = true
    var color: Color = Palette.ink

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        RevealPass(text: text, color: color, animated: animated && !reduceMotion)
            .id(text)
    }
}

private struct RevealPass: View {
    let text: String
    let color: Color
    let animated: Bool
    @State private var progress: Double

    init(text: String, color: Color, animated: Bool) {
        self.text = text
        self.color = color
        self.animated = animated
        _progress = State(initialValue: animated ? 0 : 1)
    }

    var body: some View {
        RevealText(text: text, progress: animated ? progress : 1, color: color)
            .task(id: animated) {
                guard animated else {
                    var transaction = Transaction(animation: nil)
                    transaction.disablesAnimations = true
                    withTransaction(transaction) { progress = 1 }
                    return
                }
                guard progress < 1 else { return }
                // Let the reserved layout appear before the words arrive.
                await Task.yield()
                guard !Task.isCancelled else { return }
                withAnimation(.linear(duration: duration)) { progress = 1 }
            }
    }

    private var duration: Double {
        min(2.5, 0.5 + Double(text.split(whereSeparator: \.isWhitespace).count) * 0.055)
    }
}

/// Transcript text with a highlighter stroke that sweeps across one phrase.
/// It can also distil: everything except that phrase fades away.
struct HighlightedText: View, Animatable {
    let text: String
    let phrase: String?
    var sweep: Double
    /// 0 shows the whole line; 1 leaves only the highlighted phrase.
    var distill: Double = 0
    var color: Color = Palette.ink

    var animatableData: AnimatablePair<Double, Double> {
        get { AnimatablePair(sweep, distill) }
        set {
            sweep = newValue.first
            distill = newValue.second
        }
    }

    var body: some View {
        Text(attributed)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
    }

    private var attributed: AttributedString {
        var result = AttributedString(text)
        result.foregroundColor = color.opacity(1 - min(max(distill, 0), 1))
        if let phrase, let range = result.range(of: phrase) {
            result[range].foregroundColor = color
        }
        applyMarker(to: &result, phrase: phrase, sweep: sweep)
        return result
    }
}
