import SwiftUI
import Foundation

/// The meeting's recording, tinted by who was speaking. It is large while the
/// audio uploads, then stays under the title as a timeline of the conversation,
/// with yellow markers wherever the summary found something worth keeping.
///
/// Two pieces of glass live on it. While the recording is processed, a small
/// lens rides the leading edge of progress. Once it is ready, pressing the
/// timeline raises a loupe that names who was speaking there; letting go opens
/// the transcript at that moment.
struct RecordingRibbon: View {
    let meeting: Meeting
    var progress: Double
    var height: CGFloat
    var showsMarks = false
    /// Reading position is independent of the recording's processing progress.
    var readingPosition: Double? = nil
    var labelBelow = false
    /// Called with a line's id when the reader lets go of the timeline.
    /// The timeline can only be scrubbed when this is set.
    var onScrub: ((Int) -> Void)? = nil

    /// Where the reader's finger is on the timeline (0 to 1), while pressed.
    @State private var scrub: Double?
    @State private var scrubLabelSize = CGSize.zero

    private var lensPosition: Double? {
        if let scrub { return scrub }
        return progress > 0 && progress < 1 ? progress : nil
    }

    private var scrubLine: TranscriptLine? {
        guard let scrub else { return nil }
        return meeting.line(at: scrub)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ribbon
            if let readingPosition {
                Text("\(meeting.timestamp(at: scrub ?? readingPosition)) / \(meeting.timestamp(at: 1))")
                    .font(TypeScale.meta)
                    .monospacedDigit()
                    .foregroundStyle(Palette.inkSoft)
                    .accessibilityLabel("Transcript position, \(meeting.timestamp(at: scrub ?? readingPosition)) of \(meeting.timestamp(at: 1))")
            }
        }
    }

    private var ribbon: some View {
        Waveform(
            progress: progress,
            height: height,
            voiceStarts: meeting.voiceStarts,
            voiceColors: meeting.voiceSpeakers.map(\.tint),
            marks: showsMarks ? meeting.markFractions : [],
            scrubPosition: scrub,
            readingPosition: scrub ?? readingPosition
        )
        .overlay {
            GeometryReader { geometry in
                let width = geometry.size.width
                let lens = min(max(height * 0.6, 28), 62)

                Color.clear
                    .contentShape(Rectangle())
                    .gesture(scrubGesture(width: width))
                    .allowsHitTesting(onScrub != nil)

                if let readingPosition, scrub == nil {
                    Capsule()
                        .fill(Palette.ink)
                        .frame(width: 2, height: height + 4)
                        .position(x: min(max(width * readingPosition, 1), width - 1), y: height / 2)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }

                if let lensPosition {
                    Color.clear
                        .frame(width: lens, height: lens)
                        .glassEffect(.clear, in: .circle)
                        .position(x: width * lensPosition, y: height / 2)
                        .transition(.scale.combined(with: .opacity))
                        .allowsHitTesting(false)
                }

                if let scrub, let line = scrubLine {
                    ScrubLabel(line: line)
                        .fixedSize()
                        .onGeometryChange(for: CGSize.self) { $0.size } action: { scrubLabelSize = $0 }
                        .position(
                            x: min(max(width * scrub, scrubLabelSize.width / 2), max(width - scrubLabelSize.width / 2, scrubLabelSize.width / 2)),
                            y: labelBelow
                                ? geometry.size.height + scrubLabelSize.height / 2 + 28
                                : -scrubLabelSize.height / 2 - 8
                        )
                        .transition(.scale(scale: 0.85, anchor: .bottom).combined(with: .opacity))
                        .allowsHitTesting(false)
                }
            }
        }
        .animation(.snappy(duration: 0.22), value: scrub == nil)
        .sensoryFeedback(.selection, trigger: scrubLine?.id)
        .accessibilityHint(onScrub == nil ? "" : "Press and drag to find a moment in the transcript")
    }

    private func scrubGesture(width: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { value in
                let fraction = min(max(value.location.x / max(width, 1), 0), 1)
                // Settle onto a marked moment when the finger is close to one.
                let nearest = meeting.markFractions.min { abs($0 - fraction) < abs($1 - fraction) }
                if let nearest, abs(nearest - fraction) < 0.018 {
                    scrub = nearest
                } else {
                    scrub = fraction
                }
            }
            .onEnded { _ in
                if let line = scrubLine {
                    onScrub?(line.id)
                }
                scrub = nil
            }
    }
}

/// The loupe identifies the speaker and moment without a truncated quote.
private struct ScrubLabel: View {
    let line: TranscriptLine

    var body: some View {
        HStack(spacing: 9) {
            SpeakerBadge(speaker: line.speaker, size: 24)
            Text(line.speaker.name)
                .font(TypeScale.label)
                .foregroundStyle(Palette.ink)
            Text(line.time)
                .font(TypeScale.meta)
                .monospacedDigit()
                .foregroundStyle(Palette.inkSoft)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .glassEffect(.regular, in: .capsule)
        .accessibilityElement(children: .combine)
    }
}

/// A ribbon of sound. Audio that has not been processed yet sits low and pale;
/// as progress passes over it, each bar rises, takes its speaker's color
/// through a soft edge, and ripples briefly before it settles.
struct Waveform: View, Animatable {
    var progress: Double
    var height: CGFloat
    /// Where each speaker turn starts (0 to 1), with the color for that turn.
    var voiceStarts: [Double] = []
    var voiceColors: [Color] = []
    /// Highlight positions (0 to 1); neighboring moments share a capsule.
    var marks: [Double] = []
    var scrubPosition: Double? = nil
    var readingPosition: Double? = nil

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase

    /// Lets progress glide between values instead of jumping bar to bar.
    var animatableData: Double {
        get { progress }
        set { progress = newValue }
    }

    var body: some View {
        let amount = min(max(progress, 0), 1)
        let isMoving = !reduceMotion && scenePhase == .active && amount < 1
        let fallback = Palette.leaf
        let empty = Palette.mist
        let starts = voiceStarts
        let colors = voiceColors
        let reading = readingPosition

        TimelineView(.animation(minimumInterval: 1.0 / 60.0, paused: !isMoving)) { timeline in
            let time = isMoving ? timeline.date.timeIntervalSinceReferenceDate : 0
            Canvas { context, size in
                Self.draw(
                    &context, size: size, progress: amount, time: time,
                    starts: starts, colors: colors, fallback: fallback, empty: empty,
                    readingPosition: reading
                )
            }
        }
        .frame(height: height + Self.markSpace)
        .overlay(alignment: .bottom) {
            WaveformHighlights(marks: marks, scrubPosition: scrubPosition)
                .frame(height: Self.markSpace)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
        .accessibilityElement()
        .accessibilityLabel("Recording")
        .accessibilityValue(readingPosition.map { "\(Int($0 * 100)) percent through the transcript" }
            ?? "\(Int(amount * 100)) percent processed")
    }

    /// Room kept beneath the bars for the marks, so the ribbon never jumps.
    private nonisolated static let markSpace: CGFloat = 14

    private nonisolated static func draw(
        _ context: inout GraphicsContext, size: CGSize, progress: Double, time: Double,
        starts: [Double], colors: [Color], fallback: Color, empty: Color,
        readingPosition: Double?
    ) {
        let barsHeight = max(size.height - markSpace, 4)
        let barWidth: CGFloat = 3
        let gap: CGFloat = 3
        let count = max(8, Int((size.width + gap) / (barWidth + gap)))
        let step = size.width / CGFloat(count)
        let head = progress * Double(count)
        let isInProgress = progress > 0 && progress < 1
        var voice = 0

        for index in 0..<count {
            let x = Double(index)
            let position = (x + 0.5) / Double(count)

            // Whoever was speaking at this point in the recording.
            while voice + 1 < starts.count, starts[voice + 1] <= position {
                voice += 1
            }
            let tint = voice < colors.count ? colors[voice] : fallback
            let readOpacity = readingPosition.map { position <= $0 ? 1.0 : 0.42 } ?? 1

            // The fixed shape of the recording: a slow swell with finer grain.
            let swell = 0.5 + 0.5 * sin(position * 9.6 + 0.6)
            let grain = abs(sin(x * 1.37) * cos(x * 0.53))
            let shape = min(max(0.16 + swell * 0.40 + grain * 0.44, 0.16), 1)

            // How far this bar is from the leading edge of progress.
            let distance = x + 0.5 - head
            let fill = min(max(0.5 - distance / 1.6, 0), 1)
            let nearHead = isInProgress ? exp(-(distance * distance) / 18) : 0

            // Unprocessed audio sits lower. Bars lift and ripple as the edge
            // passes, and processed bars keep a very slight breath.
            let ripple = sin(time * 3.2 - x * 0.55)
            let breath = isInProgress ? sin(time * 1.1 + x * 0.21) : 0
            var level = shape * (0.62 + 0.38 * fill)
            level *= 1 + 0.30 * nearHead * (0.6 + 0.4 * ripple) + 0.05 * fill * breath

            let barHeight = max(barWidth, CGFloat(min(level, 1)) * barsHeight)
            let rect = CGRect(
                x: CGFloat(index) * step + (step - barWidth) / 2,
                y: (barsHeight - barHeight) / 2,
                width: barWidth,
                height: barHeight
            )
            let bar = Path(roundedRect: rect, cornerRadius: barWidth / 2)
            context.fill(bar, with: .color(empty))
            if fill > 0 {
                context.fill(bar, with: .color(tint.opacity(fill * readOpacity)))
            }
        }

    }
}

/// Separate from the animated bars so marker emphasis also animates once
/// processing has finished and the waveform's timeline is paused.
private struct WaveformHighlights: View {
    let marks: [Double]
    let scrubPosition: Double?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        GeometryReader { geometry in
            let positions = HighlightMarkerLayout.positions(marks, width: geometry.size.width)
            let groups = HighlightMarkerLayout.groups(positions)
            let active = HighlightMarkerLayout.activeGroup(
                at: scrubPosition.map { CGFloat($0) * geometry.size.width },
                positions: positions, groups: groups
            )

            ForEach(groups.indices, id: \.self) { index in
                let group = groups[index]
                let diameter: CGFloat = active == index ? 9 : 7
                Capsule()
                    .fill(Palette.sun)
                    .frame(width: group.upperBound - group.lowerBound + diameter, height: diameter)
                    .position(x: (group.lowerBound + group.upperBound) / 2, y: geometry.size.height - 5)
            }
            .animation(reduceMotion ? nil : .snappy(duration: 0.18), value: active)
        }
    }
}

/// Group in screen space, preserving the original moments for navigation.
private enum HighlightMarkerLayout {
    nonisolated static func positions(_ marks: [Double], width: CGFloat) -> [CGFloat] {
        guard width.isFinite, width > 0 else { return [] }
        let inset = min(4.5, width / 2)
        return marks.filter(\.isFinite).map {
            min(max(CGFloat(min(max($0, 0), 1)) * width, inset), width - inset)
        }.sorted()
    }

    nonisolated static func groups(_ positions: [CGFloat]) -> [ClosedRange<CGFloat>] {
        var groups: [ClosedRange<CGFloat>] = []
        for position in positions {
            // A 7-point marker plus 6 points of clear space between markers.
            if let last = groups.last, position - last.upperBound < 13 {
                groups[groups.count - 1] = last.lowerBound...position
            } else {
                groups.append(position...position)
            }
        }
        return groups
    }

    nonisolated static func activeGroup(
        at position: CGFloat?, positions: [CGFloat], groups: [ClosedRange<CGFloat>]
    ) -> Int? {
        guard let position, position.isFinite,
              let nearest = positions.min(by: { abs($0 - position) < abs($1 - position) }),
              abs(nearest - position) <= 14 else { return nil }
        return groups.firstIndex { $0.contains(nearest) }
    }
}
